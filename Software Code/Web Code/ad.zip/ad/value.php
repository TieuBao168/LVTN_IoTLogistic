<?php
	
	$dbhost = 'localhost';
	$dbname = 'do_an';
	$dbuser = 'do_an';
	$dbpass = '123456';
$connect = @mysqli_connect($dbhost,$dbuser,$dbpass,$dbname);
		
		if(isset($_POST['value'])){
			$value = $_POST['value'];			
		$result = mysqli_query($connect,"INSERT INTO value (value) VALUES ('$value')");
		}
	
	?>