<?php
 $con = mysqli_connect("localhost","do_an","123456","do_an");
$a = $_POST['username'];
$b = $_POST['password'];
$sql = "select * from login2 where username= '$a' and password = '$b'"; 
$rs = mysqli_query($con,$sql);

if (mysqli_num_rows($rs) > 0){
	header("Location: information2.php");
}else{
	require_once('index.php');
	echo '<script language="javascript">';
	echo 'alert("sai tài khoản hoặc mật khẩu")';
	echo '</script>';
}
?>