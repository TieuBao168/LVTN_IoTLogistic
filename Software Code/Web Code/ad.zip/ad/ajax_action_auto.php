<?php
	
	$dbhost = 'localhost';
	$dbname = 'do_an';
	$dbuser = 'do_an';
	$dbpass = '123456';
$connect = @mysqli_connect($dbhost,$dbuser,$dbpass,$dbname);
		
		if(isset($_GET['tem1'])){
			$tem1 = $_GET['tem1'];
			
		$result = mysqli_query($connect,"INSERT INTO info1 (nhiet_do) VALUES ('$tem1')");
		}
	
	?>