
<?php
	
	$dbhost = 'localhost';
	$dbname = 'do_an';
	$dbuser = 'do_an';
	$dbpass = '123456';
	try{
		$dbcon = new PDO("mysql:host={$dbhost};dbname={$dbname}",$dbuser,$dbpass);
		$dbcon->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	}catch(PDOException $ex){
		die($ex->getMessage());
	}
	$stmt=$dbcon->prepare("SELECT * FROM iot_project");
	$stmt->execute();
	$json = [];
			while($row = $stmt-> fetch(PDO::FETCH_ASSOC))
			{
				extract($row);
				
				$json[]=[(float)$id, (float)$temperature];
				
			}
		echo json_encode($json);
	?>
