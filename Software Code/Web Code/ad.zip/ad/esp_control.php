<?php include('ab.php');?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    
    <title>He Thong Dieu Khien</title>
    <link rel = "stylesheet" type="text/css" href="style.css"/>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body  align="center">
 		<br />
		<header> 
       
        <br />
         
   	 
      </h2>
      </header>
    <script>
     var res = "success";
    </script>
   <?php
  
   $jsonString = file_get_contents("test/test.json");
   $data = json_decode($jsonString, true); //take a json encode string and convert it into a PHP variable
	
	  $user='abcd_ef';
    $auto='abcd_ef';
	if(isset($_POST['LED1_ON']))
	{
		if($user==$_POST['LED1_ON'])
		{
		  $data['led1'] = "on";		
		}
	}

	if(isset($_POST['LED1_OFF']))
	{
		if($user==$_POST['LED1_OFF'])
		{
		  $data['led1'] = "off";
		}
	}	

     $data['Auto'] = "$nhiet_do;";                         
	$newJsonString = json_encode($data);
	file_put_contents("test/test.json", $newJsonString);
   ?>       
 <form action="esp_control.php" method="post">       
	
		
            	<img id="myImage1" src="pic_bulboff10.png" width="60" height="60">
           
        <p>
            <?php
			       $user='abcd_ef';
             $auto=20;
            
              echo "
                    <label>CHỌN CHẾ ĐỘ</label>
  <br>
  
  <br>
  <div class='btn-group btn-group-toggle' data-toggle='buttons'>
  <label class='btn btn-secondary active'>
    <input id='bt1' type='radio' name='LED1_ON' id='option1' autocomplete='off'> BẰNG TAY
  </label>
  <label class='btn btn-secondary'>
    <input id='bt2' type='radio' name='options' id='option2' autocomplete='off'> TỰ ĐỘNG
  </label>
</div>
<br>
<br>
<div id='on' class='btn-group btn-group-toggle' data-toggle='buttons'>
  <label class='btn btn-secondary active'>
    <button  type='submit' name='LED1_ON' value='$user' id='option1' > ON </button>
  </label>
  <label class='btn btn-secondary'>
    <button type='submit' name='LED1_OFF' value='$user' id='option2' > OFF </button>
  </label>
</div>
  <br>
  
              ";
		      	?>

				</p>
    
<div>

 </form>
<div id='of'>
  <label>CHON NHIET DO</label>
          <iframe src='auto.php' scrolling='no' style='border:none; width: 1000px; height: 1000px;  overflow: hidden;></iframe>
          
          <br>
  <input type='button' name='insert' value='XONG' class='btn btn-primery' id='click_button'>
  </div>
 <?php
   $jsonString = file_get_contents("test/test.json");
	$data = json_decode($jsonString, true);
 
 if ($data['led1'] == 'on')
 {
	
   	echo "  <script> document.getElementById('myImage1').src = 'pic_bulbon10.png' </script>";  	
 }
 
 
 ?>
 
 <script type="text/javascript">
      document.getElementById("of").style.display = 'none';
      document.getElementById("on").style.display = 'none';
    </script>

    <script type="text/javascript">
    document.getElementById("bt1").onclick = function () {
      document.getElementById("on").style.display = 'block';
      document.getElementById("of").style.display = 'none';
            };
 
    document.getElementById("bt2").onclick = function () {
        document.getElementById("of").style.display = 'block';
        document.getElementById("on").style.display = 'none';
            };
  </script>


  


   