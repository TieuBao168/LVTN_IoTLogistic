<?php
	
	$dbhost = 'localhost';
	$dbname = 'do_an';
	$dbuser = 'do_an';
	$dbpass = '123456';
$connect = @mysqli_connect($dbhost,$dbuser,$dbpass,$dbname);
		
		if(isset($_GET['name1'])){
			$name1 = $_GET['name1'];
			$xuat_phat1 = $_GET['xuat_phat1'];
			$dich_den1 = $_GET['dich_den1'];
			$thoi_gian1 = $_GET['thoi_gian1'];
			$ket_thuc1 = $_GET['ket_thuc1'];
			$dien_thoai1 = $_GET['dien_thoai1'];
			$tin_nhan1 = $_GET['tin_nhan1'];
		$result = mysqli_query($connect,"INSERT INTO info1 (name1,xuat_phat1,dich_den1,thoi_gian1,dien_thoai1,tin_nhan1) VALUES ('$name1','$xuat_phat1','$dich_den1','$thoi_gian1','$dien_thoai1','$tin_nhan1')");
		}
	
	?>